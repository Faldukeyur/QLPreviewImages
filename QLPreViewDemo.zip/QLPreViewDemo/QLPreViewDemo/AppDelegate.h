//
//  AppDelegate.h
//  QLPreViewDemo
//
//  Created by keyur on 31/03/17.
//  Copyright © 2017 Vervesysteam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

