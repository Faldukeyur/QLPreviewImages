//
//  ViewController.h
//  QLPreViewDemo
//
//  Created by keyur on 31/03/17.
//  Copyright © 2017 Vervesysteam. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuickLook/QuickLook.h>

@interface ViewController : UIViewController<QLPreviewControllerDelegate,QLPreviewControllerDataSource>{
    
    IBOutlet UIButton *btnOpen;
    IBOutlet UIButton *btnQLPreview;

}

- (IBAction)openFromLocalPath:(id)sender;
- (IBAction)openFromQLPreview:(id)sender;


@end

