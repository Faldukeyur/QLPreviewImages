//
//  ViewController.m
//  QLPreViewDemo
//
//  Created by keyur on 31/03/17.
//  Copyright © 2017 Vervesysteam. All rights reserved.
//

#import "ViewController.h"
#import <AMPPreviewController/AMPPreviewController.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (IBAction)openFromLocalPath:(id)sender{
    
    NSURL *documentsDirectoryPath = [NSURL fileURLWithPath:[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject]];
    //NSURL *path = [documentsDirectoryPath URLByAppendingPathComponent:@"Request.pdf"];
    NSURL *path = [documentsDirectoryPath URLByAppendingPathComponent:@"ReadMe.txt"];

    NSLog(@"File Path :- %@",path);
    AMPPreviewController *pc = [[AMPPreviewController alloc] initWithFilePath:path];
    
    [self presentViewController:pc animated:YES completion:nil];

}

- (IBAction)openFromQLPreview:(id)sender{
    
    QLPreviewController *previewController = [[QLPreviewController alloc] init];
    previewController.delegate = self;
    previewController.dataSource = self;
    [self presentViewController:previewController animated:YES completion:nil];
    [previewController.navigationItem setRightBarButtonItem:nil];
}

- (NSInteger)numberOfPreviewItemsInPreviewController:(QLPreviewController *)controller
{
    return 1;
}

- (id<QLPreviewItem>)previewController:(QLPreviewController *)controller previewItemAtIndex:(NSInteger)index
{
    NSString* documentsPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString *filePath = [documentsPath
                          stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.pdf", @"Request"]];
    
    BOOL fileExists = [[NSFileManager defaultManager] fileExistsAtPath:filePath];
    if (fileExists == NO) {
        
        NSData *pdfData = [[NSData alloc] initWithContentsOfURL:[ NSURL URLWithString:@"url_to_pdf"]];
        [pdfData writeToFile:filePath atomically:YES];
    }
    NSURL *pdfUrl = [NSURL fileURLWithPath:filePath];
    return pdfUrl;
}

@end
